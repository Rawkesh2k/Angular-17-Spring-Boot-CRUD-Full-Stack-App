package com.springboot.angular.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAngularBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
